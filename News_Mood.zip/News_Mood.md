
News_Mood
The observed trends are
1. tweets of CBS has high positive polarity
2.tweets of New York times has negative polarity
3.tweets of Fox and CNN are more of neutral


```python
# Dependencies
import tweepy
import numpy as np
import pandas as pd
from datetime import datetime
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib import style
style.use('ggplot')

# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
from tweet_config import (consumer_key, 
                    consumer_secret, 
                    access_token, 
                    access_token_secret)

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
### News outlets
target_group=['@CNN','@BBC','@CBS','@nytimes','@FoxNews']

# Variables for holding sentiments
sentiments = []
for target_term in target_group:
    oldest_tweet= None
    # Counter
    counter = 1
    for x in range(4):
        public_tweets = api.user_timeline(target_term, count=25, max_id=oldest_tweet,page=x)
        #looping over 100 tweets 25tweets in each pages(5)
        for tweet in public_tweets:
            polarity = analyzer.polarity_scores(tweet["text"])
            
            tweets_ago = counter
            #appending to sentiment list
            sentiments.append({"Date": tweet["created_at"], 
                           "NewsOrg":target_term,
                         "Text":tweet["text"],
                          "Compound":polarity["compound"],
                          "Positive":polarity["pos"],
                          "Neutral": polarity["neu"],
                          "Negative":polarity["neg"],
                          "Tweets Ago": counter})
            counter+=1
    oldest_tweet = tweet['id'] - 1
```


```python
#changing the sentiment list into dataframe
sentiments_df = pd.DataFrame.from_dict(sentiments)
```


```python
sentiments_df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>NewsOrg</th>
      <th>Positive</th>
      <th>Text</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.4019</td>
      <td>Tue Apr 10 18:46:07 +0000 2018</td>
      <td>0.0</td>
      <td>0.876</td>
      <td>@CNN</td>
      <td>0.124</td>
      <td>RT @CNNPolitics: White House press secretary S...</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0772</td>
      <td>Tue Apr 10 18:40:58 +0000 2018</td>
      <td>0.0</td>
      <td>0.920</td>
      <td>@CNN</td>
      <td>0.080</td>
      <td>Facebook CEO Mark Zuckerberg is testifying bef...</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0000</td>
      <td>Tue Apr 10 18:35:01 +0000 2018</td>
      <td>0.0</td>
      <td>1.000</td>
      <td>@CNN</td>
      <td>0.000</td>
      <td>Facebook CEO Mark Zuckerberg has arrived to te...</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.6249</td>
      <td>Tue Apr 10 18:31:02 +0000 2018</td>
      <td>0.0</td>
      <td>0.814</td>
      <td>@CNN</td>
      <td>0.186</td>
      <td>Snowfall across the great white continent of A...</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.6204</td>
      <td>Tue Apr 10 18:18:00 +0000 2018</td>
      <td>0.0</td>
      <td>0.612</td>
      <td>@CNN</td>
      <td>0.388</td>
      <td>Apple is now completely powered by clean energ...</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentiments_df.to_csv("sentiment_output.csv")
```


```python
#ploting the sentiments of each news media
sns.set()
sns.lmplot(x='Tweets Ago', y='Compound', data=sentiments_pd, hue="NewsOrg", fit_reg=False , size=6,
           scatter_kws={"s":70}, scatter=True)
now = datetime.now()
now = now.strftime("%Y-%m-%d %H:%M")
plt.title(f"Sentiment Analysis of Tweets ({now}) for {target_group}")

plt.ylabel("Tweet Polarity")
plt.xlabel("Tweets Ago")
plt.show()
```


![png](output_6_0.png)


### Overall Media Sentiment


```python
#Grouping the sentiment dataframe by news meadia
overall_media_sentiment=sentiments_df.groupby("NewsOrg",as_index=False).agg({"Compound":"mean",
                                                              "Negative":"mean",
                                                              "Neutral":"mean",
                                                              "Positive":"mean"})

```


```python
overall_media_sentiment.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>NewsOrg</th>
      <th>Compound</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>0.143665</td>
      <td>0.05129</td>
      <td>0.83819</td>
      <td>0.11051</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@CBS</td>
      <td>0.360828</td>
      <td>0.01394</td>
      <td>0.84551</td>
      <td>0.14052</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@CNN</td>
      <td>0.011280</td>
      <td>0.05544</td>
      <td>0.88025</td>
      <td>0.06431</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@FoxNews</td>
      <td>0.025233</td>
      <td>0.08861</td>
      <td>0.81522</td>
      <td>0.09614</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@nytimes</td>
      <td>-0.009190</td>
      <td>0.05907</td>
      <td>0.87967</td>
      <td>0.06125</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot('NewsOrg', "Compound", data=overall_media_sentiment, linewidth=0.5, edgecolor=".3")
now = datetime.now()
now = now.strftime("%Y-%m-%d %H:%M")
plt.title(f"Overall Sentiment Analysis of Tweets ({now}) for {target_group}")

plt.ylabel("Tweet Polarity")
plt.show()
```


![png](output_10_0.png)

